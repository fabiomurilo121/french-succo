# Parle-Juh - Assets Pack

## Conteúdo

### Ícones do menu (formato outline minimalista)
- `png/` - Arquivos PNG (1:1, 2048x2048, sem marca d'água)
- `ico/` - Arquivos ICO multi-tamanho (16, 32, 48, 64, 128, 256)

### Ícones disponíveis
- inicio - Casa
- flashcards - Cartões
- completar_frases - Balão de fala
- historias - Livro aberto
- conjugacao - Grade/tabela
- pronuncia - Auto-falante
- adivinhar_audio - Auto-falante com interrogação
- conversar - Dois balões
- placas_rua - Placa de rua
- detalhes - Gráfico de barras
- configuracoes - Engrenagem

### Logos
- logo_principal - Versão principal com caixinha de suco
- logo_main - Versão moderna
- logo_premium - Versão premium
- logo_playful - Versão divertida

## Uso em HTML

### PNG (recomendado para web)
```html
<img src="png/inicio.png" alt="Início" width="24" height="24" />
```

### Para converter para SVG embutido
Use os PNGs como base e converta online se necessário.

### Para favicon
Use qualquer arquivo da pasta `ico/`.
